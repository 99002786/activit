#ifndef __FUNCTION_H__
#define __FUNCTION_H__

#include <stdio.h>
int add(int, int);
int sub(int, int);
int mul(int, int);
int Div(int, int);
#endif
