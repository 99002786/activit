#include<function.h>

int add(int x,int y){
    int z = x + y;
    return z;
}   

int sub(int a,int b){
    int c = a - b;
    return  c;
}   

int mul(int d,int e)
{
    int f = d * e;
    return f;
}

int Div(int g,int h){
    int i = g / h;
    return i;
}
